from __future__ import annotations

import html
import os
import smtplib
import ssl

from datetime import datetime, timezone
from email.message import EmailMessage
from email.utils import formataddr
from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parent.parent


# ============================================================
# ENVIRONMENT HELPER
# ============================================================

def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()

    if not value:
        raise RuntimeError(
            f"Missing environment variable: {name}"
        )

    return value


# ============================================================
# EMBED ALIA LOGO INTO HTML EMAIL
# ============================================================

def embed_alia_logo(message: EmailMessage) -> None:
    """
    Embeds the ALIA logo using CID so the recipient's
    email client does not need access to our website
    to display the image.
    """

    logo_path = (
        PROJECT_ROOT
        / "assets"
        / "images"
        / "alia-logo.png"
    )

    if not logo_path.exists():
        return

    with logo_path.open("rb") as logo_file:
        logo_data = logo_file.read()

    payload = message.get_payload()

    if not isinstance(payload, list) or not payload:
        return

    # The HTML alternative is the latest MIME part.
    html_part = payload[-1]

    html_part.add_related(
        logo_data,
        maintype="image",
        subtype="png",
        cid="<alia-logo>",
        filename="alia-logo.png",
        disposition="inline",
    )


# ============================================================
# MAIN CONTACT EMAIL FUNCTION
# ============================================================

def send_contact_email(
    *,
    name: str,
    phone: str,
    email: str,
    purpose: str,
) -> None:

    # ========================================================
    # AWS SES SMTP CONFIGURATION
    # ========================================================

    smtp_host = required_env(
        "ALIA_SES_SMTP_HOST"
    )

    smtp_port = int(
        os.getenv(
            "ALIA_SES_SMTP_PORT",
            "587",
        )
    )

    smtp_username = required_env(
        "ALIA_SES_SMTP_USERNAME"
    )

    smtp_password = required_env(
        "ALIA_SES_SMTP_PASSWORD"
    )

    from_email = required_env(
        "ALIA_CONTACT_FROM_EMAIL"
    )

    from_name = os.getenv(
        "ALIA_CONTACT_FROM_NAME",
        "ALIA",
    ).strip()

    support_email = required_env(
        "ALIA_CONTACT_TO_EMAIL"
    )

    support_name = os.getenv(
        "ALIA_CONTACT_TO_NAME",
        "ALIA Support",
    ).strip()


    # ========================================================
    # ESCAPE VALUES FOR HTML DISPLAY
    # ========================================================

    safe_name = html.escape(name)

    safe_phone = html.escape(phone)

    safe_email = html.escape(email)

    safe_purpose = html.escape(
        purpose
    ).replace(
        "\n",
        "<br>",
    )

    submitted_at = datetime.now(
        timezone.utc
    ).strftime(
        "%d %b %Y, %H:%M UTC"
    )

    current_year = datetime.now().year


    # ========================================================
    # EMAIL 1
    # INTERNAL ALIA NOTIFICATION
    # ========================================================

    internal_message = EmailMessage()

    internal_message["Subject"] = (
        f"[ALIA] New Website Enquiry - {name}"
    )

    internal_message["From"] = formataddr(
        (
            from_name,
            from_email,
        )
    )

    internal_message["To"] = formataddr(
        (
            support_name,
            support_email,
        )
    )

    # When ALIA team clicks Reply,
    # reply directly to the customer.
    internal_message["Reply-To"] = email


    # --------------------------------------------------------
    # INTERNAL EMAIL - PLAIN TEXT FALLBACK
    # --------------------------------------------------------

    internal_plain_text = f"""
ALIA — Auto Offers Live Intelligent Agent
Confidence in Every Car Deal

NEW WEBSITE ENQUIRY

A new enquiry has been submitted through the ALIA website.

Name:
{name}

Phone:
{phone}

Email:
{email}

Purpose of Visit:
{purpose}

Submitted:
{submitted_at}

Website:
https://alia-auto.ai/

Markets:
UAE · KSA · Qatar · Kuwait

---
ALIA
Auto Offers Live Intelligent Agent
Confidence in Every Car Deal
""".strip()

    internal_message.set_content(
        internal_plain_text
    )


    # --------------------------------------------------------
    # INTERNAL EMAIL - HTML
    # --------------------------------------------------------

    internal_html = f"""
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>
<title>ALIA Website Enquiry</title>
</head>

<body
style="
    margin:0;
    padding:0;
    background:#f4f6fa;
    font-family:Arial,Helvetica,sans-serif;
    color:#1C3664;
"
>

<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    background:#f4f6fa;
    padding:32px 12px;
"
>

<tr>
<td align="center">

<table
role="presentation"
width="680"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    max-width:680px;
    background:#ffffff;
    border:1px solid #e2e6ef;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 12px 35px rgba(28,54,100,0.08);
"
>


<!-- ==================================================
     HEADER
     ================================================== -->

<tr>

<td
style="
    padding:24px 32px;
    background:#ffffff;
"
>

<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
>

<tr>

<td
width="80"
valign="middle"
style="
    width:80px;
    padding-right:16px;
"
>

<img
src="cid:alia-logo"
alt="ALIA"
width="72"
style="
    display:block;
    width:72px;
    height:auto;
    border:0;
"
>

</td>


<td valign="middle">

<div
style="
    color:#1C3664;
    font-size:17px;
    font-weight:800;
    letter-spacing:1px;
    text-transform:uppercase;
    line-height:1.25;
"
>

<span style="color:#F26428;">A</span>uto Offers
<span style="color:#F26428;">L</span>ive
<span style="color:#F26428;">I</span>ntelligent
<span style="color:#F26428;">A</span>gent

</div>

<div
style="
    margin-top:5px;
    color:#111111;
    font-size:10px;
    font-weight:600;
    letter-spacing:1.3px;
    text-transform:uppercase;
"
>
Confidence in Every Car Deal
</div>

</td>

</tr>

</table>

</td>

</tr>


<!-- ==================================================
     BRAND ACCENT
     ================================================== -->

<tr>

<td
style="
    height:4px;
    background:#F26428;
    font-size:0;
    line-height:4px;
"
>
&nbsp;
</td>

</tr>


<!-- ==================================================
     INTRO
     ================================================== -->

<tr>

<td
style="
    padding:38px 40px 20px;
"
>

<div
style="
    display:inline-block;
    padding:6px 11px;
    background:#fff3ed;
    color:#F26428;
    border-radius:20px;
    font-size:10px;
    font-weight:700;
    letter-spacing:1px;
    text-transform:uppercase;
"
>
WEBSITE ENQUIRY
</div>


<h1
style="
    margin:18px 0 10px;
    color:#1C3664;
    font-size:30px;
    line-height:1.15;
    font-weight:800;
"
>
New ALIA Website Enquiry
</h1>


<p
style="
    margin:0;
    max-width:520px;
    color:#6B778F;
    font-size:15px;
    line-height:1.7;
"
>
A new enquiry has been submitted through the ALIA website.
The customer's contact information and requirement are
provided below.
</p>

</td>

</tr>


<!-- ==================================================
     CONTACT DETAILS
     ================================================== -->

<tr>

<td
style="
    padding:18px 40px 10px;
"
>

<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    background:#F8F9FB;
    border:1px solid #E2E6EF;
    border-radius:14px;
"
>


<tr>

<td
width="150"
style="
    padding:18px 20px;
    border-bottom:1px solid #E2E6EF;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.6px;
"
>
Name
</td>

<td
style="
    padding:18px 20px;
    border-bottom:1px solid #E2E6EF;
    color:#1C3664;
    font-size:15px;
    font-weight:700;
"
>
{safe_name}
</td>

</tr>


<tr>

<td
style="
    padding:18px 20px;
    border-bottom:1px solid #E2E6EF;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.6px;
"
>
Phone
</td>

<td
style="
    padding:18px 20px;
    border-bottom:1px solid #E2E6EF;
    color:#1C3664;
    font-size:15px;
    font-weight:600;
"
>

<a
href="tel:{safe_phone}"
style="
    color:#1C3664;
    text-decoration:none;
"
>
{safe_phone}
</a>

</td>

</tr>


<tr>

<td
style="
    padding:18px 20px;
    border-bottom:1px solid #E2E6EF;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.6px;
"
>
Email
</td>

<td
style="
    padding:18px 20px;
    border-bottom:1px solid #E2E6EF;
    font-size:15px;
    font-weight:600;
"
>

<a
href="mailto:{safe_email}"
style="
    color:#F26428;
    text-decoration:none;
"
>
{safe_email}
</a>

</td>

</tr>


<tr>

<td
valign="top"
style="
    padding:18px 20px;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.6px;
"
>
Purpose of Visit
</td>

<td
style="
    padding:18px 20px;
    color:#1C3664;
    font-size:15px;
    line-height:1.65;
"
>
{safe_purpose}
</td>

</tr>

</table>

</td>

</tr>


<!-- ==================================================
     SUBMITTED TIME
     ================================================== -->

<tr>

<td
style="
    padding:22px 40px 8px;
    color:#96A0B5;
    font-size:12px;
    line-height:1.7;
"
>

<strong style="color:#6B778F;">
Submitted:
</strong>

{submitted_at}

</td>

</tr>


<!-- ==================================================
     REPLY BUTTON
     ================================================== -->

<tr>

<td
align="center"
style="
    padding:26px 40px 40px;
"
>

<table
role="presentation"
cellspacing="0"
cellpadding="0"
border="0"
>

<tr>

<td
align="center"
bgcolor="#F26428"
style="
    border-radius:8px;
"
>

<a
href="mailto:{safe_email}?subject=Re:%20ALIA%20Website%20Enquiry"
style="
    display:inline-block;
    padding:14px 28px;
    background:#F26428;
    color:#ffffff;
    font-size:14px;
    font-weight:700;
    text-decoration:none;
    border-radius:8px;
"
>
Reply to Enquiry
</a>

</td>

</tr>

</table>


<p
style="
    margin:16px 0 0;
    color:#96A0B5;
    font-size:11px;
    line-height:1.6;
"
>
Clicking the button above opens a reply addressed to
{safe_email}.
</p>

</td>

</tr>


<!-- ==================================================
     INTERNAL FOOTER
     ================================================== -->

<tr>

<td
style="
    padding:26px 32px;
    background:#1C3664;
"
>

<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
>

<tr>

<td valign="top">

<div
style="
    color:#ffffff;
    font-size:12px;
    font-weight:700;
"
>
ALIA — Auto Offers Live Intelligent Agent
</div>

<div
style="
    margin-top:5px;
    color:#F26428;
    font-size:10px;
    font-weight:600;
    letter-spacing:.7px;
    text-transform:uppercase;
"
>
Confidence in Every Car Deal
</div>

</td>


<td
align="right"
valign="top"
style="
    color:#AAB5C9;
    font-size:11px;
"
>
UAE · KSA · Qatar · Kuwait
</td>

</tr>

</table>


<div
style="
    margin-top:20px;
    padding-top:16px;
    border-top:1px solid rgba(255,255,255,.12);
    color:#8796B2;
    font-size:10px;
    line-height:1.6;
"
>

This notification was generated automatically
from the ALIA website contact form.

<br>

© {current_year} ALIA. All rights reserved.

</div>

</td>

</tr>


</table>

</td>

</tr>

</table>

</body>

</html>
"""

    internal_message.add_alternative(
        internal_html,
        subtype="html",
    )

    embed_alia_logo(
        internal_message
    )


    # ========================================================
    # EMAIL 2
    # CUSTOMER ACKNOWLEDGEMENT
    # ========================================================

    acknowledgement_message = EmailMessage()

    acknowledgement_message["Subject"] = (
        "Thank You for Contacting ALIA-AUTO.AI"
    )

    acknowledgement_message["From"] = formataddr(
        (
            from_name,
            from_email,
        )
    )

    # IMPORTANT:
    # Use the original validated email for SMTP recipient.
    acknowledgement_message["To"] = (email)

    # If customer replies to acknowledgement,
    # send that reply to ALIA Support.
    acknowledgement_message["Reply-To"] = (
        support_email
    )


    # --------------------------------------------------------
    # ACKNOWLEDGEMENT - PLAIN TEXT FALLBACK
    # --------------------------------------------------------

    acknowledgement_plain_text = f"""
ALIA — Auto Offers Live Intelligent Agent
Confidence in Every Car Deal

THANK YOU FOR CONTACTING ALIA

Hello {name},

Thank you for reaching out to ALIA.

We have successfully received your enquiry.
Our team will review your requirement and get back
to you shortly.

YOUR REQUEST

Name:
{name}

Phone:
{phone}

Email:
{email}

Purpose of Visit:
{purpose}

WHAT HAPPENS NEXT?

1. Our team will review your requirement.

2. The appropriate ALIA representative will contact you.

3. We may request additional information if required.

Need assistance?

Email:
{support_email}

Website:
https://alia-auto.ai/

ALIA
Auto Offers Live Intelligent Agent
Confidence in Every Car Deal

UAE · KSA · Qatar · Kuwait

© {current_year} ALIA. All rights reserved.
""".strip()


    acknowledgement_message.set_content(
        acknowledgement_plain_text
    )


    # --------------------------------------------------------
    # ACKNOWLEDGEMENT - HTML
    # --------------------------------------------------------

    acknowledgement_html = f"""
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Thank You for Contacting ALIA-AUTO.AI
</title>

</head>


<body
style="
    margin:0;
    padding:0;
    background:#F4F6FA;
    font-family:Arial,Helvetica,sans-serif;
    color:#1C3664;
"
>


<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    background:#F4F6FA;
    padding:36px 12px;
"
>


<tr>

<td align="center">


<table
role="presentation"
width="680"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    max-width:680px;
    background:#FFFFFF;
    border:1px solid #E2E6EF;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 12px 35px rgba(28,54,100,0.08);
"
>


<!-- ==================================================
     HEADER
     ================================================== -->

<tr>

<td
style="
    padding:24px 32px;
    background:#FFFFFF;
"
>


<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
>


<tr>


<td
width="80"
valign="middle"
style="
    width:80px;
    padding-right:16px;
"
>

<img
src="cid:alia-logo"
alt="ALIA"
width="72"
style="
    display:block;
    width:72px;
    height:auto;
    border:0;
"
>

</td>


<td valign="middle">


<div
style="
    color:#1C3664;
    font-size:17px;
    font-weight:800;
    line-height:1.25;
    text-transform:uppercase;
    letter-spacing:1px;
"
>

<span style="color:#F26428;">A</span>uto Offers
<span style="color:#F26428;">L</span>ive
<span style="color:#F26428;">I</span>ntelligent
<span style="color:#F26428;">A</span>gent

</div>


<div
style="
    margin-top:5px;
    color:#111111;
    font-size:10px;
    font-weight:600;
    letter-spacing:1.3px;
    text-transform:uppercase;
"
>
Confidence in Every Car Deal
</div>


</td>


</tr>


</table>


</td>

</tr>


<!-- ==================================================
     ORANGE BRAND ACCENT
     ================================================== -->

<tr>

<td
style="
    height:4px;
    line-height:4px;
    background:#F26428;
    font-size:0;
"
>
&nbsp;
</td>

</tr>


<!-- ==================================================
     ACKNOWLEDGEMENT HERO
     ================================================== -->

<tr>

<td
style="
    padding:40px 40px 24px;
"
>


<div
style="
    display:inline-block;
    padding:6px 12px;
    background:#FFF3ED;
    color:#F26428;
    border-radius:999px;
    font-size:10px;
    font-weight:700;
    letter-spacing:1px;
    text-transform:uppercase;
"
>
ENQUIRY RECEIVED
</div>


<h1
style="
    margin:18px 0 12px;
    color:#1C3664;
    font-size:30px;
    line-height:1.2;
    font-weight:800;
"
>
Thank You for Contacting ALIA-AUTO.AI
</h1>


<p
style="
    margin:0 0 18px;
    color:#1C3664;
    font-size:16px;
    line-height:1.7;
"
>
Hello {safe_name},
</p>


<p
style="
    margin:0;
    color:#6B778F;
    font-size:15px;
    line-height:1.75;
"
>

Thank you for reaching out to ALIA.

We have successfully received your enquiry.
Our team will review your requirement and get back
to you shortly.

</p>


</td>

</tr>


<!-- ==================================================
     CONFIRMATION STATUS
     ================================================== -->

<tr>

<td
style="
    padding:0 40px 26px;
"
>

<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    background:#F0FAF4;
    border:1px solid #B7E4C7;
    border-radius:12px;
"
>

<tr>

<td
width="50"
align="center"
style="
    padding:18px 0 18px 18px;
    color:#1A8A50;
    font-size:24px;
    font-weight:800;
"
>
✓
</td>

<td
style="
    padding:18px 18px 18px 12px;
"
>

<div
style="
    color:#1A6B38;
    font-size:14px;
    font-weight:800;
"
>
Your enquiry was received successfully
</div>

<div
style="
    margin-top:4px;
    color:#4E7C5D;
    font-size:12px;
    line-height:1.5;
"
>
No further action is required from you at this time.
</div>

</td>

</tr>

</table>

</td>

</tr>


<!-- ==================================================
     YOUR REQUEST
     ================================================== -->

<tr>

<td
style="
    padding:0 40px;
"
>


<div
style="
    margin-bottom:12px;
    color:#1C3664;
    font-size:12px;
    font-weight:800;
    letter-spacing:.8px;
    text-transform:uppercase;
"
>
Your Request
</div>


<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
style="
    width:100%;
    background:#F8F9FB;
    border:1px solid #E2E6EF;
    border-radius:12px;
"
>


<tr>

<td
width="150"
style="
    padding:16px 18px;
    border-bottom:1px solid #E2E6EF;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
"
>
Name
</td>

<td
style="
    padding:16px 18px;
    border-bottom:1px solid #E2E6EF;
    color:#1C3664;
    font-size:14px;
    font-weight:700;
"
>
{safe_name}
</td>

</tr>


<tr>

<td
style="
    padding:16px 18px;
    border-bottom:1px solid #E2E6EF;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
"
>
Phone
</td>

<td
style="
    padding:16px 18px;
    border-bottom:1px solid #E2E6EF;
    color:#1C3664;
    font-size:14px;
"
>
{safe_phone}
</td>

</tr>


<tr>

<td
style="
    padding:16px 18px;
    border-bottom:1px solid #E2E6EF;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
"
>
Email
</td>

<td
style="
    padding:16px 18px;
    border-bottom:1px solid #E2E6EF;
    color:#1C3664;
    font-size:14px;
"
>
{safe_email}
</td>

</tr>


<tr>

<td
valign="top"
style="
    padding:16px 18px;
    color:#6B778F;
    font-size:12px;
    font-weight:700;
"
>
Purpose of Visit
</td>

<td
style="
    padding:16px 18px;
    color:#1C3664;
    font-size:14px;
    line-height:1.6;
"
>
{safe_purpose}
</td>

</tr>


</table>


</td>

</tr>


<!-- ==================================================
     NEXT STEPS
     ================================================== -->

<tr>

<td
style="
    padding:30px 40px 0;
"
>


<div
style="
    padding:22px 24px;
    background:#F4F6FA;
    border-radius:12px;
"
>


<div
style="
    margin-bottom:14px;
    color:#1C3664;
    font-size:15px;
    font-weight:800;
"
>
What happens next?
</div>


<table
role="presentation"
cellspacing="0"
cellpadding="0"
border="0"
>


<tr>

<td
valign="top"
style="
    padding:5px 12px 5px 0;
    color:#F26428;
    font-size:14px;
    font-weight:800;
"
>
1.
</td>

<td
style="
    padding:5px 0;
    color:#6B778F;
    font-size:14px;
    line-height:1.6;
"
>
Our team will review your requirement.
</td>

</tr>


<tr>

<td
valign="top"
style="
    padding:5px 12px 5px 0;
    color:#F26428;
    font-size:14px;
    font-weight:800;
"
>
2.
</td>

<td
style="
    padding:5px 0;
    color:#6B778F;
    font-size:14px;
    line-height:1.6;
"
>
The appropriate ALIA representative will contact you.
</td>

</tr>


<tr>

<td
valign="top"
style="
    padding:5px 12px 5px 0;
    color:#F26428;
    font-size:14px;
    font-weight:800;
"
>
3.
</td>

<td
style="
    padding:5px 0;
    color:#6B778F;
    font-size:14px;
    line-height:1.6;
"
>
We may request additional information if required.
</td>

</tr>


</table>


</div>


</td>

</tr>


<!-- ==================================================
     SUPPORT
     ================================================== -->

<tr>

<td
align="center"
style="
    padding:28px 40px 38px;
"
>


<p
style="
    margin:0;
    color:#6B778F;
    font-size:13px;
    line-height:1.7;
"
>

Need assistance?

Contact us at

<a
href="mailto:{support_email}"
style="
    color:#F26428;
    font-weight:700;
    text-decoration:none;
"
>
{support_email}
</a>

</p>


</td>

</tr>


<!-- ==================================================
     CUSTOMER FOOTER
     ================================================== -->

<tr>

<td
style="
    padding:26px 32px;
    background:#1C3664;
"
>


<table
role="presentation"
width="100%"
cellspacing="0"
cellpadding="0"
border="0"
>


<tr>


<td valign="top">

<div
style="
    color:#FFFFFF;
    font-size:12px;
    font-weight:700;
"
>
ALIA — Auto Offers Live Intelligent Agent
</div>

<div
style="
    margin-top:5px;
    color:#F26428;
    font-size:10px;
    font-weight:600;
    letter-spacing:.7px;
    text-transform:uppercase;
"
>
Confidence in Every Car Deal
</div>

</td>


<td
align="right"
valign="top"
style="
    color:#AAB5C9;
    font-size:11px;
    line-height:1.6;
"
>
UAE · KSA · Qatar · Kuwait
</td>


</tr>


</table>


<div
style="
    margin-top:20px;
    padding-top:16px;
    border-top:1px solid rgba(255,255,255,.12);
    color:#8796B2;
    font-size:10px;
    line-height:1.6;
"
>

This is an automated confirmation that your enquiry
was received by ALIA.

<br>

Please do not share sensitive or confidential information
by replying to this automated email.

<br><br>

© {current_year} ALIA. All rights reserved.

</div>


</td>

</tr>


</table>


</td>

</tr>


</table>


</body>

</html>
"""

    acknowledgement_message.add_alternative(
        acknowledgement_html,
        subtype="html",
    )

    embed_alia_logo(
        acknowledgement_message
    )


    # ========================================================
    # SEND BOTH EMAILS USING ONE AWS SES SMTP CONNECTION
    # ========================================================

    context = ssl.create_default_context()

    with smtplib.SMTP(
        smtp_host,
        smtp_port,
        timeout=30,
    ) as smtp:

        smtp.ehlo()

        smtp.starttls(
            context=context
        )

        smtp.ehlo()

        smtp.login(
            smtp_username,
            smtp_password,
        )


        # ----------------------------------------------------
        # EMAIL 1:
        # Internal ALIA notification
        # ----------------------------------------------------

        print(
            f"[ALIA MAIL] Sending internal email to: {support_email}",
            file=sys.stderr,
            flush=True,
        )

        internal_result = smtp.send_message(
            internal_message
        )

        print(
            f"[ALIA MAIL] Internal send result: {internal_result}",
            file=sys.stderr,
            flush=True,
        )


        # ----------------------------------------------------
        # EMAIL 2:
        # Customer acknowledgement
        # ----------------------------------------------------

        print(
            f"[ALIA MAIL] Sending acknowledgement to: {email}",
            file=sys.stderr,
            flush=True,
        )

        try:
            acknowledgement_result = smtp.send_message(
                acknowledgement_message
            )

            print(
                (
                    "[ALIA MAIL] Customer acknowledgement "
                    f"send result: {acknowledgement_result}"
                ),
                file=sys.stderr,
                flush=True,
            )

        except Exception as exc:
            print(
                (
                    "[ALIA MAIL] CUSTOMER ACKNOWLEDGEMENT FAILED: "
                    f"{type(exc).__name__}: {exc}"
                ),
                file=sys.stderr,
                flush=True,
            )

            raise